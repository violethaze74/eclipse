

public class ChainedThing {

	public static int i = 9;
}
