

public class SimpleThing {

	public static int i = ChainedThing.i;
}
