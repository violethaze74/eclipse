public class EmptyClass {}
