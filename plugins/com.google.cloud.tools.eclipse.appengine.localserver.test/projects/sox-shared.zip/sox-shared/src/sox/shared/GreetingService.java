package sox.shared;

public interface GreetingService {
}
